package factory;

public enum Sabor {
	queijo, portuguesa
}
