package factory;

public class Pizzaria {

	private Pizza pizza;

    public void criarPizza(Sabor tipo ){


            if( tipo == tipo.queijo ){
            	return new Queijo();
            }
            else if( tipo == tipo.portuguesa){
            	return new Portuguesa();
            }
    }

    public Pizza delivery(){
        return pizza;
    }
}
