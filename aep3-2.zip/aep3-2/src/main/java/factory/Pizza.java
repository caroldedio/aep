package factory;

public class Pizza {

}
