package observer;

import java.util.ArrayList;
import java.util.List;

public class Dieta implements Observavel {

	 private List observers = new ArrayList();
     private double peso;

     public Dieta(double peso) {
          this.peso = peso;
     }

     public void setPeso(double peso) {
    	 this.peso = peso;
    	 this.notificarObservers();
     }

     @Override
     public void novoObserver(Observavel observer) {
          observers.add(observer);
     }

     @Override
     public void removerObserver(Observavel observer) {
          observers.remove(observer);
     }

     @Override
     public void notificarObservers() {
          for (ObserverClass ob : observers) {
          System.out.println("Notificando observers!");
            ob.update(this.peso);
          }
     }
}
