package observer;

public interface Observavel {

    public void removerObserver(Observavel observer);
    public void notificarObservers();
	public void novoObserver(Observavel observer); 

}
