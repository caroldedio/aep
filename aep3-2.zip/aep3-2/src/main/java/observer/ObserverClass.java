package observer;

public interface ObserverClass {

	void update(Object objeto);
}
