package observer;

import javax.swing.JOptionPane;

public class App {
	
	 public static void main(String args[]) {
	        Dieta dieta = new Dieta(180);
	        dieta.setPeso(150);
	    }
	 
}