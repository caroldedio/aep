package bulder;

public enum Massa {
	BRANCA
}
